load('config.js');
function execute(input, page) {
    var parts = String(input || "").split("|");
    var id = parts[0], param = parts[1] || "";
    var p = parseInt(page || "1", 10) || 1;
    var b = boardById(id);
    if (!b) return Response.error("BXH không tồn tại: " + id);
    var list = b.kind === "agg" ? getAggregate(b.id) : getBoard(id, param, true);
    if (!list.length) return Response.error("Chưa tải được " + boardTitle(b) + " — thử lại sau");
    var size = 30, start = (p - 1) * size;
    var items = renderItems(list, start, size, b.kind === "agg" ? null : b);
    return Response.success(items, start + size < list.length ? String(p + 1) : "");
}
