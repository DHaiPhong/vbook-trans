function execute() {
    return Response.success([
        { id: "zh", type: "from" },
        { id: "ja", type: "from" },
        { id: "vi", type: "to" },
        { id: "en", type: "to" }
    ]);
}
