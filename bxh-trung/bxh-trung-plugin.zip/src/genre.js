load('config.js');
var QD_CATS = [["玄幻 Huyền huyễn", 21], ["奇幻 Kỳ huyễn", 1], ["武侠 Võ hiệp", 2], ["仙侠 Tiên hiệp", 22], ["都市 Đô thị", 4], ["现实 Hiện thực", 15], ["军事 Quân sự", 6], ["历史 Lịch sử", 5], ["游戏 Du hí", 7], ["体育 Thể thao", 8], ["科幻 Khoa huyễn", 9], ["诸天无限 Chư thiên vô hạn", 20109], ["悬疑 Huyền nghi", 10], ["轻小说 Light novel", 12]];
var FQ_M = ["西方奇幻", "东方仙侠", "科幻末世", "都市日常", "都市修真", "都市高武", "历史古代", "战神赘婿", "都市种田", "传统玄幻", "历史脑洞", "悬疑脑洞", "都市脑洞", "玄幻脑洞", "悬疑灵异", "抗战谍战", "游戏体育", "动漫衍生", "男频衍生"];
var FQ_F = ["古风世情", "科幻末世", "游戏体育", "女频衍生", "玄幻言情", "种田", "年代", "现言脑洞", "宫斗宅斗", "悬疑脑洞", "古言脑洞", "快穿", "青春甜宠", "星光璀璨", "女频悬疑", "职场婚恋", "豪门总裁", "民国言情"];

function execute() {
    var gs = channels(), out = [];
    if (gs.indexOf("m") !== -1) {
        QD_CATS.forEach(function (c) { out.push({ title: "QD Nguyệt phiếu · " + c[0], input: "qd_yuepiao|" + c[1], script: "rank.js" }); });
        FQ_M.forEach(function (c) { out.push({ title: "FQ Nam · " + c, input: "fq_male_read|" + c, script: "rank.js" }); });
    }
    if (gs.indexOf("f") !== -1) {
        FQ_F.forEach(function (c) { out.push({ title: "FQ Nữ · " + c, input: "fq_female_read|" + c, script: "rank.js" }); });
    }
    return Response.success(out);
}
