load('config.js');
// Trang chủ: các tab chính, xếp theo kỳ (Tổng hợp → Ngày → Tuần → Tháng → Tổng → Mới)
function execute() {
    var gs = channels(), tabs = [];
    gs.forEach(function (g) {
        var list = BOARDS.filter(function (b) { return b.g === g && b.home; });
        var aggs = list.filter(function (b) { return b.kind === "agg"; });
        var rest = list.filter(function (b) { return b.kind !== "agg"; });
        PER_ORDER.forEach(function (per) {
            rest.forEach(function (b) { if ((b.per || "") === per) aggs.push(b); });
        });
        aggs.forEach(function (b) { tabs.push({ title: boardTitle(b), input: b.id, script: "rank.js" }); });
    });
    return Response.success(tabs);
}
