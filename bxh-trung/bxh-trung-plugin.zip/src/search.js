load('config.js');
// Tìm trong các BXH đang có (theo tên gốc, Hán Việt hoặc tác giả)
function execute(query, page) {
    var q = fold(query);
    if (!q) return Response.success([], "");
    var seen = {}, hits = [];
    channels().forEach(function (g) {
        BOARDS.forEach(function (b) {
            if (b.g !== g || b.kind === "agg") return;
            getBoard(b.id, "", false).forEach(function (it, i) {
                var k = normTitle(it.t);
                if (seen[k]) return;
                var hay = fold(it.t + " " + (it.a || "") + " " + hvName(it.t));
                if (hay.indexOf(q) === -1) return;
                seen[k] = 1;
                saveMeta(it, [{ id: b.id, b: b.short, r: i + 1, v: it.v || "" }]);
                hits.push(toListItem(it, i + 1));
            });
        });
    });
    return Response.success(hits, "");
}

function fold(s) {
    s = String(s || "").toLowerCase().trim();
    try { s = s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d"); } catch (e) { }
    return s;
}
