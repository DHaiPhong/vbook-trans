load('config.js');
function execute() {
    var gs = channels();
    var tabs = [];
    BOARDS.forEach(function (b) {
        if (gs.indexOf(b.g) === -1) return;
        tabs.push({ title: b.title, input: b.id, script: "rank.js" });
    });
    return Response.success(tabs);
}
