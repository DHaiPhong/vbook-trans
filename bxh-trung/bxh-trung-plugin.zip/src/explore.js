load('config.js');
function execute() {
    var sections = [];
    channels().forEach(function (g) {
        BOARDS.forEach(function (b) {
            if (b.g !== g || !b.ex) return;
            var list = b.kind === "agg" ? getAggregate(b.id) : getBoard(b.id, "", false);
            if (list.length) sections.push(makeSection(b, renderItems(list, 0, 10, b.kind === "agg" ? null : b)));
        });
    });
    if (!sections.length) return Response.error("Không tải được BXH nào — kiểm tra mạng rồi thử lại");
    return Response.success(sections);
}

function makeSection(b, items) {
    var more = { type: "list", name: boardTitle(b), script: "rank.js", input: b.id, data: "" };
    return { id: b.id, title: boardTitle(b), subtitle: b.sub || "", type: "ranking", items: items, more: more, action: more };
}
