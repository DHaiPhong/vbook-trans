var GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
var GOOGLE_URL = "https://translate.googleapis.com/translate_a/single";
var MAX_TOTAL_CHARS = 1000;

function cfgValue(value, fallback) {
    return (value !== undefined && value !== null && String(value) !== "") ? String(value) : fallback;
}

function readApiKeys() {
    var raw = cfgValue(typeof gemini_key !== "undefined" ? gemini_key : "", "");
    if (!raw) raw = cfgValue(typeof api_key !== "undefined" ? api_key : "", "");
    if (!raw) return [];
    var arr;
    try {
        arr = JSON.parse(raw);
    } catch (e) {
        arr = raw.split(/[\n,;\s]+/);
    }
    if (!Array.isArray(arr)) arr = [String(arr)];
    var keys = [];
    for (var i = 0; i < arr.length; i++) {
        var k = String(arr[i]).trim();
        if (k) keys.push(k);
    }
    return keys;
}

function readModel() {
    return cfgValue(typeof model !== "undefined" ? model : "", "gemini-flash-latest");
}

function readVowelStyle() {
    return cfgValue(typeof long_vowel !== "undefined" ? long_vowel : "", "Satou");
}

function vowelRule(style) {
    if (style === "Sato") {
        return "Drop long vowels entirely, no macrons: 佐藤 → Sato, 龙之介 → Ryunosuke, 大野 → Ono, 优子 → Yuko.";
    }
    if (style === "Satō") {
        return "Use Hepburn macrons for long vowels: 佐藤 → Satō, 龙之介 → Ryūnosuke, 大野 → Ōno, 优子 → Yūko.";
    }
    return "Write long vowels the way they are spelled in kana, no macrons: 佐藤 → Satou, 龙之介 → Ryuunosuke, 大野 → Oono, 优子 → Yuuko.";
}

function buildPrompt(style) {
    return [
        "You convert Japanese names that a Chinese web novel writes in Chinese characters into their Japanese reading in romaji.",
        "",
        "Input: a JSON array of strings. Output: a JSON array of strings with exactly the same length and order, one romaji result per input item.",
        "",
        "Rules:",
        "1. The characters are often Simplified Chinese forms of Japanese kanji (见→見, 泽→沢/澤, 樱→桜, 龙→竜/龍, 边→辺, 滨→浜). Read them as the Japanese name they stand for.",
        "2. Use the reading a Japanese person would actually use for that name, not a character-by-character reading. Examples: 伏见诚 → Fushimi Makoto, 樱岛麻衣 → Sakurajima Mai, 雪之下雪乃 → Yukinoshita Yukino.",
        "3. Keep Japanese order (family name first). Capitalize each word and put a space between family name and given name.",
        "4. Long vowels: " + vowelRule(style),
        "5. An honorific attached to a name becomes a lowercase hyphenated suffix: 酱 → -chan, 君 → -kun, 桑 → -san, 前辈 → -senpai, 老师 → -sensei, 大人/様 → -sama.",
        "6. A foreign name written phonetically in Chinese becomes its likely original spelling: 艾莉丝 → Alice.",
        "7. Place names, schools and organizations get their Japanese reading: 秋叶原 → Akihabara.",
        "8. If an item is not Japanese, still give the most plausible Japanese romaji reading.",
        "9. Output only the JSON array. No kanji, no notes, no explanations."
    ].join("\n");
}

function normalizeVowels(s, style) {
    if (style === "Satō") return s;
    var map = style === "Sato"
        ? { "ā": "a", "ī": "i", "ū": "u", "ē": "e", "ō": "o", "â": "a", "î": "i", "û": "u", "ê": "e", "ô": "o",
            "Ā": "A", "Ī": "I", "Ū": "U", "Ē": "E", "Ō": "O", "Â": "A", "Î": "I", "Û": "U", "Ê": "E", "Ô": "O" }
        : { "ā": "aa", "ī": "ii", "ū": "uu", "ē": "ee", "ō": "ou", "â": "aa", "î": "ii", "û": "uu", "ê": "ee", "ô": "ou",
            "Ā": "Aa", "Ī": "Ii", "Ū": "Uu", "Ē": "Ee", "Ō": "Ou", "Â": "Aa", "Î": "Ii", "Û": "Uu", "Ê": "Ee", "Ô": "Ou" };
    var out = "";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        out += map[c] !== undefined ? map[c] : c;
    }
    return out;
}

function titleCase(s) {
    var words = s.split(" ");
    for (var i = 0; i < words.length; i++) {
        var w = words[i];
        if (w.length > 0) words[i] = w.charAt(0).toUpperCase() + w.substring(1).toLowerCase();
    }
    return words.join(" ");
}

function geminiText(data) {
    if (!data || !data.candidates || data.candidates.length === 0) return "";
    var c = data.candidates[0];
    if (!c || !c.content || !c.content.parts) return "";
    var text = "";
    for (var i = 0; i < c.content.parts.length; i++) {
        var p = c.content.parts[i];
        if (p && p.text && !p.thought) text += String(p.text);
    }
    return text;
}

function pad2(n) {
    return (n < 10 ? "0" : "") + n;
}

function nthSundayUTC(year, month, n, hourUTC) {
    var day = new Date(Date.UTC(year, month, 1)).getUTCDay();
    var date = 1 + ((7 - day) % 7) + (n - 1) * 7;
    return Date.UTC(year, month, date, hourUTC);
}

function pacificOffset(now) {
    var y = now.getUTCFullYear();
    var t = now.getTime();
    return (t >= nthSundayUTC(y, 2, 2, 10) && t < nthSundayUTC(y, 10, 1, 9)) ? -7 : -8;
}

function pacificDay(now) {
    var p = new Date(now.getTime() + pacificOffset(now) * 3600000);
    return p.getUTCFullYear() + "-" + pad2(p.getUTCMonth() + 1) + "-" + pad2(p.getUTCDate());
}

function vnClock(now) {
    var v = new Date(now.getTime() + 7 * 3600000);
    return pad2(v.getUTCHours()) + ":" + pad2(v.getUTCMinutes());
}

function resetHourVN(now) {
    return (7 - pacificOffset(now)) + ":00";
}

function keyLabel(key) {
    return "…" + key.substring(key.length - 4);
}

function formatNum(n) {
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function storageGet(k) {
    try {
        if (typeof localStorage === "undefined") return "";
        var v = localStorage.getItem(k);
        return v ? String(v) : "";
    } catch (e) {
        return "";
    }
}

function storageSet(k, v) {
    try {
        if (typeof localStorage !== "undefined") localStorage.setItem(k, v);
    } catch (e) {}
}

function loadUsage(now) {
    var u = null;
    try {
        u = JSON.parse(storageGet("usage_json") || "null");
    } catch (e) {}
    if (!u || typeof u !== "object") u = {};
    if (!u.limits) u.limits = {};
    var today = pacificDay(now);
    if (u.day !== today) {
        u.day = today;
        u.models = {};
        u.exhausted = {};
        u.lastError = "";
    }
    if (!u.models) u.models = {};
    if (!u.exhausted) u.exhausted = {};
    return u;
}

function configLimit() {
    var v = cfgValue(typeof rpd_limit !== "undefined" ? rpd_limit : "", "");
    var n = parseInt(v, 10);
    return isNaN(n) || n <= 0 ? 0 : n;
}

function saveUsage(u, now) {
    storageSet("usage_json", JSON.stringify(u));
    var lines = ["Ngày " + u.day + " theo giờ Mỹ (reset lúc " + resetHourVN(now) + " giờ VN)"];
    var fixed = configLimit();
    var hasAny = false;
    for (var em in u.exhausted) {
        if (!u.models[em]) u.models[em] = {};
    }
    for (var m in u.models) {
        var perKey = u.models[m];
        var total = 0;
        for (var k in perKey) {
            hasAny = true;
            var s = perKey[k];
            total += s.req;
            lines.push(m + " · key " + k + ": " + formatNum(s.req) + " lượt, " + formatNum(s.tok) + " token (lần cuối " + s.last + ")");
        }
        var limit = fixed || parseInt(u.limits[m] || "0", 10);
        if (u.exhausted[m]) {
            lines.push("→ " + m + ": đã hết quota hôm nay (Google báo), chờ reset lúc " + resetHourVN(now) + " giờ VN");
        } else if (limit > 0) {
            lines.push("→ " + m + ": còn khoảng " + formatNum(Math.max(limit - total, 0)) + "/" + formatNum(limit) + " lượt hôm nay");
        } else {
            lines.push("→ " + m + ": chưa biết giới hạn (nhập ở cài đặt, hoặc sẽ tự biết khi hết quota)");
        }
    }
    if (!hasAny) lines.push("Hôm nay chưa dùng Gemini.");
    if (u.lastError) lines.push("Lỗi gần nhất: " + u.lastError);
    lines.push("Chỉ đếm lượt gọi từ extension này. Quota tính theo project, key cùng project dùng chung.");
    storageSet("thong_ke", lines.join("\n"));
}

function recordSuccess(modelName, key, data, now) {
    var u = loadUsage(now);
    if (!u.models[modelName]) u.models[modelName] = {};
    var label = keyLabel(key);
    var s = u.models[modelName][label] || { req: 0, tok: 0, last: "" };
    var tok = 0;
    if (data && data.usageMetadata && data.usageMetadata.totalTokenCount) {
        tok = parseInt(String(data.usageMetadata.totalTokenCount), 10) || 0;
    }
    s.req += 1;
    s.tok += tok;
    s.last = vnClock(now);
    u.models[modelName][label] = s;
    delete u.exhausted[modelName];
    saveUsage(u, now);
}

function parseGeminiError(response) {
    var info = { message: "", quotaId: "", limit: "", retry: "" };
    try {
        var d = response.json();
        var e = d && d.error;
        if (e) {
            info.message = String(e.message || "");
            var details = e.details || [];
            for (var i = 0; i < details.length; i++) {
                var t = String(details[i]["@type"] || "");
                if (t.indexOf("QuotaFailure") >= 0 && details[i].violations && details[i].violations.length > 0) {
                    var v = details[i].violations[0];
                    info.quotaId = String(v.quotaId || "");
                    info.limit = String(v.quotaValue || "");
                } else if (t.indexOf("RetryInfo") >= 0) {
                    info.retry = String(details[i].retryDelay || "");
                }
            }
        }
    } catch (ex) {}
    if (!info.limit) {
        var m = info.message.match(/limit:\s*(\d+)/);
        if (m) info.limit = m[1];
    }
    if (!info.message) info.message = "HTTP " + response.status;
    return info;
}

function describeQuota(info, modelName, now) {
    var id = info.quotaId;
    var limitText = info.limit ? " (giới hạn " + formatNum(info.limit) + ")" : "";
    if (id.indexOf("PerDay") >= 0) {
        var unit = id.indexOf("Token") >= 0 ? " token/ngày" : " lượt/ngày";
        return "Hết quota ngày của " + modelName + (info.limit ? " (giới hạn " + formatNum(info.limit) + unit + ")" : "")
            + ". Reset lúc " + resetHourVN(now) + " giờ VN, hoặc đổi sang model khác.";
    }
    if (id.indexOf("PerMinute") >= 0) {
        return "Quá giới hạn mỗi phút" + limitText + ". Thử lại sau " + (info.retry || "ít giây") + ".";
    }
    return "Hết quota: " + info.message.substring(0, 200);
}

function recordQuotaError(modelName, key, info, now) {
    var u = loadUsage(now);
    if (info.limit && info.quotaId.indexOf("PerDay") >= 0 && info.quotaId.indexOf("Token") < 0) {
        u.limits[modelName] = info.limit;
    }
    if (info.quotaId.indexOf("PerDay") >= 0) u.exhausted[modelName] = true;
    u.lastError = vnClock(now) + ", key " + keyLabel(key) + ": " + describeQuota(info, modelName, now);
    saveUsage(u, now);
}

function postGemini(url, body, key) {
    try {
        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": key },
            body: JSON.stringify(body),
            timeout: 25000
        });
    } catch (e) {
        return null;
    }
}

function thinkingOptions(modelName) {
    if (modelName.indexOf("gemini-2") === 0) return [{ thinkingBudget: 0 }, null];
    return [{ thinkingLevel: "minimal" }, { thinkingLevel: "low" }, null];
}

function romajiByGemini(inputs, keys) {
    var modelName = readModel();
    var style = readVowelStyle();
    var url = GEMINI_BASE + "/" + modelName + ":generateContent";
    var body = {
        systemInstruction: { parts: [{ text: buildPrompt(style) }] },
        contents: [{ role: "user", parts: [{ text: JSON.stringify(inputs) }] }],
        generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json",
            responseSchema: { type: "ARRAY", items: { type: "STRING" } }
        }
    };
    var options = thinkingOptions(modelName);
    var cacheKey = "thinking_" + modelName;
    var optIndex = parseInt(storageGet(cacheKey) || "0", 10);
    if (isNaN(optIndex) || optIndex < 0 || optIndex >= options.length) optIndex = 0;

    var lastQuotaMsg = "";
    for (var i = 0; i < keys.length; i++) {
        var response = null;
        while (true) {
            if (options[optIndex]) body.generationConfig.thinkingConfig = options[optIndex];
            else delete body.generationConfig.thinkingConfig;
            response = postGemini(url, body, keys[i]);
            if (response && !response.ok && response.status === 400 && optIndex < options.length - 1) {
                optIndex++;
                continue;
            }
            break;
        }
        if (!response) {
            return { error: "Gemini không phản hồi sau 25 giây (mạng chậm hoặc Google quá tải). Thử lại, hoặc dùng nút vi." };
        }
        var now = new Date();
        if (response.ok) {
            storageSet(cacheKey, String(optIndex));
            var data;
            try {
                data = response.json();
            } catch (e) {
                return { error: "Gemini trả về dữ liệu lỗi." };
            }
            recordSuccess(modelName, keys[i], data, now);
            var text = geminiText(data).replace(/```json|```/g, "").trim();
            var arr;
            try {
                arr = JSON.parse(text);
            } catch (e2) {
                return { error: "Gemini trả về không đúng định dạng: " + text.substring(0, 200) };
            }
            if (!Array.isArray(arr) || arr.length !== inputs.length) {
                return { error: "Gemini trả về sai số dòng (" + (arr && arr.length) + "/" + inputs.length + ")" };
            }
            var out = [];
            for (var j = 0; j < arr.length; j++) out.push(normalizeVowels(String(arr[j]).trim(), style));
            return { data: out };
        }
        var info = parseGeminiError(response);
        if (response.status === 429) {
            recordQuotaError(modelName, keys[i], info, now);
            lastQuotaMsg = describeQuota(info, modelName, now);
            continue;
        }
        if (response.status === 403) {
            lastQuotaMsg = "Key " + keyLabel(keys[i]) + " không hợp lệ hoặc không có quyền: " + info.message.substring(0, 150);
            continue;
        }
        if (response.status === 404) {
            return { error: "Model " + modelName + " không tồn tại hoặc đã ngừng. Đổi model khác trong cài đặt." };
        }
        return { error: "Gemini lỗi (HTTP " + response.status + "): " + info.message.substring(0, 200) };
    }
    return { error: lastQuotaMsg || "Tất cả API key đều lỗi." };
}

function pickRomaji(data, index) {
    if (!data || !data[0]) return "";
    var parts = data[0];
    var s = "";
    for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        if (p && (p[0] === null || p[0] === undefined) && p.length > index && p[index]) {
            s += String(p[index]);
        }
    }
    return s.trim();
}

function romajiByGoogle(inputs, from) {
    var style = readVowelStyle();
    var isJa = from === "ja";
    var out = [];
    for (var i = 0; i < inputs.length; i++) {
        var url = GOOGLE_URL + "?client=gtx&sl=" + (isJa ? "ja" : "zh-CN") + "&tl=" + (isJa ? "en" : "ja")
            + "&dt=t&dt=rm&q=" + encodeURIComponent(inputs[i]);
        var response;
        try {
            response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() }, timeout: 15000 });
        } catch (e) {
            return { error: "Google Translate không phản hồi sau 15 giây. Thử lại, hoặc dùng nút en." };
        }
        if (!response.ok) {
            if (response.status === 429) return { error: "Google Translate tạm chặn vì gọi quá nhiều. Đợi một lúc hoặc dùng nút en." };
            return { error: "Google Translate lỗi HTTP " + response.status };
        }
        var data;
        try {
            data = response.json();
        } catch (e2) {
            return { error: "Google Translate trả về trang lạ (có thể đang bị chặn tạm). Đợi một lúc hoặc dùng nút en." };
        }
        var romaji = pickRomaji(data, isJa ? 3 : 2);
        if (!romaji) return { error: "Google Translate không trả về phiên âm cho: " + inputs[i] };
        out.push(normalizeVowels(titleCase(romaji), style));
    }
    return { data: out };
}
