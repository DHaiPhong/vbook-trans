load('config.js');
function execute(url) {
    var link = officialLink(url) + "#bxh";
    var meta = loadMeta(link) || metaFromUrl(link);
    if (!meta) return Response.error("Không có dữ liệu truyện");
    var stv = stvLink(meta);
    var html = "<p>" + infoHtml(meta) + "</p>";
    html += "<p><b>Cách đọc:</b> BXH này chỉ để chọn truyện. Copy tên gốc bên dưới, dán vào ô tìm kiếm của vBook để tìm trong các nguồn Trung bạn đã cài.</p>";
    html += "<p>" + esc(meta.t) + (meta.a ? " " + esc(meta.a) : "") + "</p>";
    if (stv) html += "<p>Link Sáng Tác Việt (dán vào vBook nếu đã cài extension STV):<br>" + stv + "</p>";
    html += "<p>Trang gốc: " + officialLink(meta.link) + "</p>";
    if (meta.d) html += "<p><b>Giới thiệu:</b><br>" + esc(meta.d) + "</p>";
    return Response.success(html, displayName(meta.t));
}
