var CFG = {
    name: "zh",
    channel: "m",
    ttl: 60,
    fq: "https://raw.githubusercontent.com/uu201/FanqieRankTracker/main",
    stv: "https://sangtacviet.vip"
};
try { CFG.name = String(NAME_MODE).split(" ")[0] || "zh"; } catch (e) { }
try { CFG.channel = String(CHANNEL).split(" ")[0] || "m"; } catch (e) { }
try { var _ttl = parseInt(CACHE_MINUTES, 10); if (_ttl >= 0) CFG.ttl = _ttl; } catch (e) { }
try { if (FANQIE_API) CFG.fq = String(FANQIE_API).replace(/\/+$/, ""); } catch (e) { }
try { if (STV_DOMAIN) CFG.stv = String(STV_DOMAIN).replace(/\/+$/, ""); } catch (e) { }

var UA_M = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
var UA_PC = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

// w = trọng số khi chấm điểm tab Tổng hợp (0 = không tính); ex = hiện ở trang Khám phá
var BOARDS = [
    { id: "agg_m", g: "m", kind: "agg", title: "🔥 Tổng hợp · Nam" },
    { id: "qd_yuepiao", g: "m", kind: "qd", path: "/rank/yuepiao/", w: 1.2, ex: 1, title: "Qidian · Nguyệt phiếu (tháng này)", short: "QD Nguyệt phiếu" },
    { id: "qd_yuepiao_prev", g: "m", kind: "qd", path: "PREV", w: 0, title: "Qidian · Nguyệt phiếu (tháng trước)", short: "QD NP tháng trước" },
    { id: "qd_hotsales", g: "m", kind: "qd", path: "/rank/hotsales/", w: 1.0, ex: 1, title: "Qidian · Bán chạy", short: "QD Bán chạy" },
    { id: "qd_readindex", g: "m", kind: "qd", path: "/rank/readindex/", w: 0.8, title: "Qidian · Chỉ số đọc", short: "QD Chỉ số đọc" },
    { id: "qd_rec", g: "m", kind: "qd", path: "/rank/rec/", w: 0.5, title: "Qidian · Đề cử", short: "QD Đề cử" },
    { id: "qd_newbook", g: "m", kind: "qd", path: "/rank/newbook/", w: 0, title: "Qidian · Sách mới", short: "QD Sách mới" },
    { id: "fq_male_read", g: "m", kind: "fq", slug: "male-read", w: 1.0, ex: 1, title: "Fanqie · Đọc nhiều (Nam)", short: "FQ Đọc nhiều" },
    { id: "fq_male_new", g: "m", kind: "fq", slug: "male-new", w: 0, title: "Fanqie · Sách mới (Nam)", short: "FQ Sách mới" },
    { id: "qm_boy_hot", g: "m", kind: "qm", path: "/paihang/boy/hot/month/", w: 0.8, ex: 1, title: "Qimao · Đại nhiệt tháng (Nam)", short: "QM Đại nhiệt" },
    { id: "qm_boy_new", g: "m", kind: "qm", path: "/paihang/boy/new/month/", w: 0, title: "Qimao · Sách mới tháng (Nam)", short: "QM Sách mới" },
    { id: "bd_m", g: "m", kind: "bd", w: 0.4, ex: 1, title: "Baidu · Hot search (Nam)", short: "Baidu" },

    { id: "agg_f", g: "f", kind: "agg", title: "🔥 Tổng hợp · Nữ" },
    { id: "fq_female_read", g: "f", kind: "fq", slug: "female-read", w: 1.0, ex: 1, title: "Fanqie · Đọc nhiều (Nữ)", short: "FQ Đọc nhiều" },
    { id: "fq_female_new", g: "f", kind: "fq", slug: "female-new", w: 0, title: "Fanqie · Sách mới (Nữ)", short: "FQ Sách mới" },
    { id: "jj_month", g: "f", kind: "jj", orderstr: "7", w: 1.0, ex: 1, title: "Tấn Giang · Bảng tháng", short: "JJ Bảng tháng" },
    { id: "qm_girl_hot", g: "f", kind: "qm", path: "/paihang/girl/hot/month/", w: 0.8, ex: 1, title: "Qimao · Đại nhiệt tháng (Nữ)", short: "QM Đại nhiệt" },
    { id: "bd_f", g: "f", kind: "bd", w: 0.4, ex: 1, title: "Baidu · Hot search (Nữ)", short: "Baidu" }
];

var PRIO = { qd: 0, fq: 1, jj: 2, qm: 3, bd: 4 };
var PLATFORM = { qd: "Qidian", fq: "Fanqie", jj: "Tấn Giang", qm: "Qimao", bd: "Baidu" };

function channels() {
    return CFG.channel === "all" ? ["m", "f"] : [CFG.channel === "f" ? "f" : "m"];
}

function boardById(id) {
    for (var i = 0; i < BOARDS.length; i++) if (BOARDS[i].id === id) return BOARDS[i];
    return null;
}

// ---------- HTTP ----------
function httpText(url, opt) {
    opt = opt || {};
    var headers = { "User-Agent": opt.pc ? UA_PC : UA_M, "Accept-Language": "zh-CN,zh;q=0.9" };
    try {
        var res = fetch(url, { headers: headers, timeout: 20000 });
        if (!res.ok) return "";
        return String(opt.charset ? res.text(opt.charset) : res.text());
    } catch (e) {
        return "";
    }
}

function browserHtml(url) {
    var b = null;
    try {
        b = Engine.newBrowser();
        var doc = b.launch(url, 15000);
        var html = doc ? String(doc.html()) : "";
        b.close();
        return html;
    } catch (e) {
        try { if (b) b.close(); } catch (e2) { }
        return "";
    }
}

// ---------- Cache ----------
function cacheGet(key, allowStale) {
    try {
        var s = cacheStorage.getItem(key);
        if (!s) return null;
        var o = JSON.parse(String(s));
        if (!allowStale && (Date.now() - o.ts) > CFG.ttl * 60000) return null;
        return o.v;
    } catch (e) {
        return null;
    }
}

function cacheSet(key, v) {
    try { cacheStorage.setItem(key, JSON.stringify({ ts: Date.now(), v: v })); } catch (e) { }
}

// ---------- Helpers ----------
function findArray(obj, test, depth) {
    depth = depth || 0;
    if (!obj || depth > 8 || typeof obj !== "object") return null;
    if (Array.isArray(obj)) {
        if (obj.length && test(obj[0])) return obj;
        for (var i = 0; i < obj.length; i++) {
            var r = findArray(obj[i], test, depth + 1);
            if (r) return r;
        }
        return null;
    }
    for (var k in obj) {
        if (!obj.hasOwnProperty(k)) continue;
        var r2 = findArray(obj[k], test, depth + 1);
        if (r2) return r2;
    }
    return null;
}

function parseWan(s) {
    var m = String(s || "").replace(/,/g, "").match(/([\d.]+)\s*(万|亿)?/);
    if (!m) return 0;
    var n = parseFloat(m[1]);
    if (m[2] === "万") n *= 1e4;
    if (m[2] === "亿") n *= 1e8;
    return n;
}

function clean(s) {
    return String(s || "").replace(/\s+/g, " ").trim();
}

function normTitle(t) {
    return String(t || "").replace(/[\s\u3000·•，,。.！!？?：:、（）()《》【】\[\]“”"'‘’—\-~～]/g, "").toLowerCase();
}

function prevMonth() {
    var d = new Date();
    var y = d.getFullYear(), m = d.getMonth();
    if (m === 0) { y = y - 1; m = 12; }
    return String(y) + (m < 10 ? "0" : "") + m;
}

// ---------- Qidian (m.qidian.com, SSR) ----------
function qdPath(b, param) {
    var cat = param ? "catid" + param + "/" : "";
    if (b.path === "PREV") return "/rank/yuepiao/" + cat + prevMonth() + "/";
    return b.path + cat;
}

function qidianRecords(html) {
    if (!html) return [];
    // Danh sách nằm trong JSON SSR của vite-plugin-ssr, không phải DOM
    var m = html.match(/<script[^>]+id=["']vite-plugin-ssr_pageContext["'][^>]*>([\s\S]*?)<\/script>/i);
    if (!m) return [];
    var obj;
    try { obj = JSON.parse(m[1]); } catch (e) { return []; }
    var pd = obj && obj.pageContext && obj.pageContext.pageProps && obj.pageContext.pageProps.pageData;
    var recs = pd && pd.records;
    if (!recs || !recs.length) {
        recs = findArray(obj, function (o) { return o && (o.bid || o.bookId) && (o.bName || o.bookName); });
    }
    return recs || [];
}

function fetchQidian(path, allowBrowser) {
    var url = "https://m.qidian.com" + path;
    var recs = qidianRecords(httpText(url));
    if (!recs.length && allowBrowser) recs = qidianRecords(browserHtml(url));
    var out = [];
    recs.forEach(function (r) {
        var bid = String(r.bid || r.bookId || "");
        var t = clean(r.bName || r.bookName);
        if (!bid || !t) return;
        out.push({
            t: t,
            a: clean(r.bAuth || r.authorName || r.author),
            c: "https://bookcover.yuewen.com/qdbimg/349573/" + bid + "/180",
            d: clean(r.desc),
            cat: [r.cat, r.subCat].filter(function (x) { return !!x; }).join("·"),
            words: r.cnt ? String(r.cnt) : "",
            v: r.rankCnt ? String(r.rankCnt) : "",
            pid: "qd", rid: bid,
            link: "https://m.qidian.com/book/" + bid + "/#bxh"
        });
    });
    return out;
}

// ---------- Fanqie (JSON đã giải mã từ FanqieRankTracker) ----------
function fetchFanqie(slug, cat) {
    var url = CFG.fq + "/api/" + slug + "/lastest/all.json";
    var txt = cacheGet("R:" + url);
    if (!txt) {
        txt = httpText(url, { pc: true });
        if (txt) cacheSet("R:" + url, txt); else txt = cacheGet("R:" + url, true);
    }
    if (!txt) return [];
    var data;
    try { data = JSON.parse(txt); } catch (e) { return []; }
    var out = [], seen = {};
    (data.categories || []).forEach(function (c) {
        if (cat && c.name !== cat) return;
        (c.books || []).forEach(function (b) {
            var m = String(b.url || "").match(/\/page\/(\d+)/);
            if (!m || seen[m[1]]) return;
            seen[m[1]] = 1;
            out.push({
                t: clean(b.title), a: clean(b.author), c: b.cover || "", d: clean(b.intro),
                cat: c.name || "", words: "",
                v: b.reads ? b.reads + " đang đọc" : "", n: parseWan(b.reads),
                pid: "fq", rid: m[1],
                link: "https://fanqienovel.com/page/" + m[1] + "#bxh"
            });
        });
    });
    if (!cat) out.sort(function (x, y) { return y.n - x.n; });
    return out;
}

// ---------- Qimao ----------
function qimaoParse(html) {
    if (!html) return [];
    var doc = Html.parse(html);
    var byId = {}, order = [];
    doc.select("a[href*='/shuku/']").forEach(function (a) {
        var m = String(a.attr("href")).match(/\/shuku\/(\d+)/);
        if (!m) return;
        var id = m[1];
        if (!byId[id]) { byId[id] = { t: "", c: "" }; order.push(id); }
        var o = byId[id];
        var t = clean(a.text());
        if (t && t.length <= 40 && !/^\d+$/.test(t) && !/^(最近更新|最新章节|最新)/.test(t) && t.length > o.t.length) o.t = t;
        var img = a.select("img");
        if (!img.isEmpty()) {
            var im = img.first();
            var src = String(im.attr("data-src") || im.attr("src") || "");
            if (src && !o.c) o.c = src.indexOf("//") === 0 ? "https:" + src : src;
            if (!o.t && im.attr("alt")) o.t = clean(im.attr("alt"));
        }
    });
    var out = [];
    order.forEach(function (id) {
        var o = byId[id];
        if (!o.t || out.length >= 50) return;
        out.push({ t: o.t, a: "", c: o.c, d: "", cat: "", words: "", v: "", pid: "qm", rid: id, link: "https://www.qimao.com/shuku/" + id + "/#bxh" });
    });
    return out;
}

function fetchQimao(path, allowBrowser) {
    var url = "https://www.qimao.com" + path;
    var list = qimaoParse(httpText(url, { pc: true }));
    if (list.length < 5 && allowBrowser) {
        var viaBrowser = qimaoParse(browserHtml(url));
        if (viaBrowser.length > list.length) list = viaBrowser;
    }
    return list;
}

// ---------- Tấn Giang (GB18030) ----------
function fetchJJ(orderstr) {
    var html = httpText("https://www.jjwxc.net/topten.php?orderstr=" + orderstr + "&t=0", { pc: true, charset: "gb18030" });
    if (!html) return [];
    var doc = Html.parse(html);
    var out = [], seen = {};
    doc.select("tr:not(:has(tr))").forEach(function (tr) {
        var ta = tr.select("a[href*='onebook.php?novelid=']");
        if (ta.isEmpty()) return;
        var a0 = ta.first();
        var m = String(a0.attr("href")).match(/novelid=(\d+)/);
        if (!m || seen[m[1]]) return;
        seen[m[1]] = 1;
        var au = tr.select("a[href*='oneauthor.php']");
        out.push({
            t: clean(a0.text()), a: au.isEmpty() ? "" : clean(au.first().text()),
            c: "", d: clean(a0.attr("title")), cat: "", words: "", v: "",
            pid: "jj", rid: m[1],
            link: "https://www.jjwxc.net/onebook.php?novelid=" + m[1] + "#bxh"
        });
    });
    return out.filter(function (x) { return !!x.t; });
}

// ---------- Baidu (s-data JSON trong comment HTML) ----------
function fetchBaiduAll() {
    var key = "B:bd_all";
    var cached = cacheGet(key);
    if (cached) return cached;
    var html = httpText("https://top.baidu.com/board?tab=novel", { pc: true });
    var out = [];
    // Baidu nhúng dữ liệu BXH dạng JSON trong <!--s-data:...-->
    var m = html.match(/<!--s-data:([\s\S]*?)-->/);
    if (m) {
        try {
            var arr = findArray(JSON.parse(m[1]), function (o) { return o && o.word; }) || [];
            arr.forEach(function (o) {
                var raw = JSON.stringify(o);
                var au = raw.match(/作者[：:]\s*([^"，,\\]+)/);
                var ct = raw.match(/类型[：:]\s*([^"，,\\|]+)/);
                var t = clean(o.word);
                out.push({
                    t: t, a: au ? clean(au[1]) : clean(o.author), c: o.img || "", d: clean(o.desc),
                    cat: ct ? clean(ct[1]) : clean(o.category), words: "",
                    v: o.hotScore ? o.hotScore + " điểm hot" : "",
                    pid: "bd", rid: t,
                    link: "https://www.baidu.com/s?wd=" + encodeURIComponent(t + " 小说") + "#bxh"
                });
            });
        } catch (e) { }
    }
    if (!out.length && html) {
        var seen = {};
        Html.parse(html).select("a[href*='fyb_novel']").forEach(function (a) {
            var mm = String(a.attr("href")).match(/[?&]wd=([^&]+)/);
            if (!mm) return;
            var t = clean(decodeURIComponent(mm[1].replace(/\+/g, " ")).replace(/\s*小说$/, ""));
            if (!t || seen[t]) return;
            seen[t] = 1;
            out.push({ t: t, a: "", c: "", d: "", cat: "", words: "", v: "", pid: "bd", rid: t, link: "https://www.baidu.com/s?wd=" + encodeURIComponent(t + " 小说") + "#bxh" });
        });
    }
    if (out.length) cacheSet(key, out); else out = cacheGet(key, true) || [];
    return out;
}

// ---------- Board / Aggregate ----------
function getBoard(id, param, allowBrowser) {
    var b = boardById(id);
    if (!b || b.kind === "agg") return [];
    param = param || "";
    var key = "B:" + id + "|" + param;
    var cached = cacheGet(key);
    if (cached) return cached;
    var list = [];
    if (b.kind === "qd") list = fetchQidian(qdPath(b, param), allowBrowser);
    else if (b.kind === "fq") list = fetchFanqie(b.slug, param);
    else if (b.kind === "qm") list = fetchQimao(b.path, allowBrowser);
    else if (b.kind === "jj") list = fetchJJ(b.orderstr);
    else if (b.kind === "bd") {
        list = fetchBaiduAll().filter(function (x) {
            var fem = /言情|青春/.test(x.cat);
            return b.g === "f" ? fem : !fem;
        });
    }
    if (list.length) cacheSet(key, list);
    else list = cacheGet(key, true) || [];
    return list;
}

function getAggregate(g, allowBrowser) {
    var key = "A:" + g;
    var cached = cacheGet(key);
    if (cached) return cached;
    var map = {}, order = [];
    BOARDS.forEach(function (b) {
        if (b.g !== g || !b.w) return;
        var list = getBoard(b.id, "", allowBrowser);
        var N = Math.min(list.length, 50);
        for (var i = 0; i < N; i++) {
            var it = list[i], k = normTitle(it.t);
            if (!k) continue;
            var e = map[k];
            if (!e) {
                e = map[k] = { it: Object.assign({}, it), score: 0, ranks: [] };
                order.push(k);
            } else {
                var cur = e.it;
                if (PRIO[it.pid] < PRIO[cur.pid]) {
                    e.it = Object.assign({}, it);
                    ["a", "c", "d", "cat", "words"].forEach(function (f) { if (!e.it[f]) e.it[f] = cur[f]; });
                } else {
                    ["a", "c", "d", "cat", "words"].forEach(function (f) { if (!cur[f]) cur[f] = it[f]; });
                }
            }
            e.score += b.w * (N - i) / N;
            e.ranks.push({ id: b.id, b: b.short, r: i + 1, v: it.v || "" });
        }
    });
    var out = order.map(function (k) {
        var e = map[k];
        var it = e.it;
        it.ranks = e.ranks.sort(function (x, y) { return x.r - y.r; });
        it.score = Math.round(e.score * 100) / 100;
        return it;
    });
    out.sort(function (x, y) { return y.score - x.score; });
    if (out.length) cacheSet(key, out);
    return out;
}

// ---------- Tên / hiển thị ----------
function qtText(text, mode) {
    if (!text) return "";
    try {
        var r = Qt.translate(String(text), mode, mode === "vp" ? { chapter_name: true, first_capitalize: true } : { first_capitalize: true });
        return r && r.translateText ? clean(r.translateText) : "";
    } catch (e) {
        return "";
    }
}

function hvName(t) {
    var s = qtText(t, "hv");
    return s ? s.replace(/(^|\s)(\S)/g, function (m0, p, c) { return p + c.toUpperCase(); }) : "";
}

function displayName(t) {
    if (CFG.name === "hv") return hvName(t) || t;
    if (CFG.name === "vp") return qtText(t, "vp") || t;
    return t;
}

function altName(t) {
    return CFG.name === "zh" ? hvName(t) : t;
}

function ranksText(ranks, max) {
    return (ranks || []).slice(0, max || 3).map(function (r) { return r.b + " #" + r.r; }).join(", ");
}

function toListItem(it, rank) {
    var parts = [];
    var alt = altName(it.t);
    if (alt) parts.push(alt);
    if (it.a) parts.push(it.a);
    if (it.ranks) parts.push(ranksText(it.ranks, 3));
    else if (it.v) parts.push(it.v);
    if (it.cat) parts.push(it.cat);
    return {
        name: displayName(it.t),
        link: it.link,
        cover: it.c || "",
        description: parts.join(" · "),
        tag: it.ranks ? it.ranks.length + " BXH" : "#" + rank
    };
}

// ---------- Meta (localStorage) để detail/chap không phải tải lại ----------
function loadMeta(link) {
    try {
        var s = localStorage.getItem("M:" + link);
        return s ? JSON.parse(String(s)) : null;
    } catch (e) {
        return null;
    }
}

function saveMeta(it, newRanks) {
    var old = loadMeta(it.link);
    var ranks = (old && old.ranks) ? old.ranks : [];
    (newRanks || []).forEach(function (nr) {
        var hit = false;
        for (var i = 0; i < ranks.length; i++) {
            if (ranks[i].id === nr.id) { ranks[i] = nr; hit = true; break; }
        }
        if (!hit) ranks.push(nr);
    });
    var m = {
        t: it.t, a: it.a || (old && old.a) || "", c: it.c || (old && old.c) || "",
        d: String(it.d || (old && old.d) || "").substring(0, 800),
        cat: it.cat || (old && old.cat) || "", words: it.words || (old && old.words) || "",
        pid: it.pid, rid: it.rid, link: it.link, ranks: ranks
    };
    try { localStorage.setItem("M:" + it.link, JSON.stringify(m)); } catch (e) { }
    return m;
}

function renderItems(list, start, count, board) {
    var out = [];
    for (var i = start; i < Math.min(list.length, start + count); i++) {
        var it = list[i];
        if (it.ranks) saveMeta(it, it.ranks);
        else if (board) saveMeta(it, [{ id: board.id, b: board.short, r: i + 1, v: it.v || "" }]);
        out.push(toListItem(it, i + 1));
    }
    return out;
}

function officialLink(link) {
    return String(link || "").replace(/#bxh.*$/, "");
}

function stvLink(m) {
    var host = { qd: "qidian", fq: "fanqie", jj: "jjwxc" }[m.pid];
    if (!host || !m.rid) return "";
    return CFG.stv + "/truyen/" + host + "/1/" + m.rid + "/";
}

function esc(s) {
    return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function metaFromUrl(url) {
    var off = officialLink(url);
    var pid = "", rid = "", m;
    if ((m = off.match(/qidian\.com\/book\/(\d+)/))) { pid = "qd"; rid = m[1]; }
    else if ((m = off.match(/fanqienovel\.com\/page\/(\d+)/))) { pid = "fq"; rid = m[1]; }
    else if ((m = off.match(/qimao\.com\/shuku\/(\d+)/))) { pid = "qm"; rid = m[1]; }
    else if ((m = off.match(/novelid=(\d+)/))) { pid = "jj"; rid = m[1]; }
    else if ((m = off.match(/[?&]wd=([^&#]+)/))) { pid = "bd"; rid = decodeURIComponent(m[1]).replace(/\s*小说$/, ""); }
    if (!pid) return null;
    if (pid === "bd") return { t: rid, a: "", c: "", d: "", cat: "", words: "", pid: pid, rid: rid, link: url, ranks: [] };
    var html = httpText(off, { pc: pid !== "qd", charset: pid === "jj" ? "gb18030" : "" });
    if (!html) return null;
    var doc = Html.parse(html);
    function metaProp(p) {
        var e = doc.select("meta[property='" + p + "']");
        return e.isEmpty() ? "" : clean(e.first().attr("content"));
    }
    var t = metaProp("og:novel:book_name") || metaProp("og:title") || clean(doc.select("title").text()).split(/[_\-|(（]/)[0];
    return {
        t: t, a: metaProp("og:novel:author"),
        c: metaProp("og:image") || (pid === "qd" ? "https://bookcover.yuewen.com/qdbimg/349573/" + rid + "/180" : ""),
        d: metaProp("og:description"), cat: metaProp("og:novel:category"), words: "",
        pid: pid, rid: rid, link: url, ranks: []
    };
}

function infoHtml(meta) {
    var lines = [];
    var hv = hvName(meta.t);
    lines.push("Tên gốc: " + esc(meta.t));
    if (hv) lines.push("Hán Việt: " + esc(hv));
    if (meta.a) lines.push("Tác giả: " + esc(meta.a));
    var sub = [];
    if (meta.cat) sub.push("Thể loại: " + esc(meta.cat));
    if (meta.words) sub.push("Số chữ: " + esc(meta.words));
    if (sub.length) lines.push(sub.join(" · "));
    lines.push("Nền tảng: " + (PLATFORM[meta.pid] || ""));
    if (meta.ranks && meta.ranks.length) {
        lines.push("Xếp hạng: " + meta.ranks.map(function (r) {
            return esc(r.b) + " #" + r.r + (r.v ? " (" + esc(r.v) + ")" : "");
        }).join(" · "));
    }
    return lines.join("<br>");
}
