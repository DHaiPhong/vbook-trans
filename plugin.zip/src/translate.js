load('common.js');

function execute(text, from, to, source) {
    text = String(text || "");
    if (text.trim() === "") return Response.success(text);
    if (text.length > MAX_TOTAL_CHARS) {
        return Response.error("Đoạn quá dài. Engine này chỉ dùng để phiên âm tên, không dùng dịch cả chương.");
    }

    var lines = text.split("\n");
    var inputs = [];
    var positions = [];
    for (var i = 0; i < lines.length; i++) {
        var t = lines[i].trim();
        if (t) {
            inputs.push(t);
            positions.push(i);
        }
    }

    var keys = readApiKeys();
    var result = keys.length > 0 ? romajiByGemini(inputs, keys) : romajiByGoogle(inputs, from || "");
    if (result.error) return Response.error(result.error);

    for (var j = 0; j < positions.length; j++) {
        lines[positions[j]] = result.data[j];
    }
    return Response.success(lines.join("\n"));
}
