var GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
var GOOGLE_URL = "https://translate.googleapis.com/translate_a/single";
var MAX_TOTAL_CHARS = 1000;

function cfgValue(value, fallback) {
    return (value !== undefined && value !== null && String(value) !== "") ? String(value) : fallback;
}

function readApiKeys() {
    var raw = cfgValue(typeof gemini_key !== "undefined" ? gemini_key : "", "");
    if (!raw) raw = cfgValue(typeof api_key !== "undefined" ? api_key : "", "");
    if (!raw) return [];
    var arr;
    try {
        arr = JSON.parse(raw);
    } catch (e) {
        arr = raw.split(/[\n,;\s]+/);
    }
    if (!Array.isArray(arr)) arr = [String(arr)];
    var keys = [];
    for (var i = 0; i < arr.length; i++) {
        var k = String(arr[i]).trim();
        if (k) keys.push(k);
    }
    return keys;
}

function readModel() {
    return cfgValue(typeof model !== "undefined" ? model : "", "gemini-flash-latest");
}

function readVowelStyle() {
    return cfgValue(typeof long_vowel !== "undefined" ? long_vowel : "", "Satou");
}

function vowelRule(style) {
    if (style === "Sato") {
        return "Drop long vowels entirely, no macrons: 佐藤 → Sato, 龙之介 → Ryunosuke, 大野 → Ono, 优子 → Yuko.";
    }
    if (style === "Satō") {
        return "Use Hepburn macrons for long vowels: 佐藤 → Satō, 龙之介 → Ryūnosuke, 大野 → Ōno, 优子 → Yūko.";
    }
    return "Write long vowels the way they are spelled in kana, no macrons: 佐藤 → Satou, 龙之介 → Ryuunosuke, 大野 → Oono, 优子 → Yuuko.";
}

function buildPrompt(style) {
    return [
        "You convert Japanese names that a Chinese web novel writes in Chinese characters into their Japanese reading in romaji.",
        "",
        "Input: a JSON array of strings. Output: a JSON array of strings with exactly the same length and order, one romaji result per input item.",
        "",
        "Rules:",
        "1. The characters are often Simplified Chinese forms of Japanese kanji (见→見, 泽→沢/澤, 樱→桜, 龙→竜/龍, 边→辺, 滨→浜). Read them as the Japanese name they stand for.",
        "2. Use the reading a Japanese person would actually use for that name, not a character-by-character reading. Examples: 伏见诚 → Fushimi Makoto, 樱岛麻衣 → Sakurajima Mai, 雪之下雪乃 → Yukinoshita Yukino.",
        "3. Keep Japanese order (family name first). Capitalize each word and put a space between family name and given name.",
        "4. Long vowels: " + vowelRule(style),
        "5. An honorific attached to a name becomes a lowercase hyphenated suffix: 酱 → -chan, 君 → -kun, 桑 → -san, 前辈 → -senpai, 老师 → -sensei, 大人/様 → -sama.",
        "6. A foreign name written phonetically in Chinese becomes its likely original spelling: 艾莉丝 → Alice.",
        "7. Place names, schools and organizations get their Japanese reading: 秋叶原 → Akihabara.",
        "8. If an item is not Japanese, still give the most plausible Japanese romaji reading.",
        "9. Output only the JSON array. No kanji, no notes, no explanations."
    ].join("\n");
}

function normalizeVowels(s, style) {
    if (style === "Satō") return s;
    var map = style === "Sato"
        ? { "ā": "a", "ī": "i", "ū": "u", "ē": "e", "ō": "o", "â": "a", "î": "i", "û": "u", "ê": "e", "ô": "o",
            "Ā": "A", "Ī": "I", "Ū": "U", "Ē": "E", "Ō": "O", "Â": "A", "Î": "I", "Û": "U", "Ê": "E", "Ô": "O" }
        : { "ā": "aa", "ī": "ii", "ū": "uu", "ē": "ee", "ō": "ou", "â": "aa", "î": "ii", "û": "uu", "ê": "ee", "ô": "ou",
            "Ā": "Aa", "Ī": "Ii", "Ū": "Uu", "Ē": "Ee", "Ō": "Ou", "Â": "Aa", "Î": "Ii", "Û": "Uu", "Ê": "Ee", "Ô": "Ou" };
    var out = "";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        out += map[c] !== undefined ? map[c] : c;
    }
    return out;
}

function titleCase(s) {
    var words = s.split(" ");
    for (var i = 0; i < words.length; i++) {
        var w = words[i];
        if (w.length > 0) words[i] = w.charAt(0).toUpperCase() + w.substring(1).toLowerCase();
    }
    return words.join(" ");
}

function geminiText(data) {
    if (!data || !data.candidates || data.candidates.length === 0) return "";
    var c = data.candidates[0];
    if (!c || !c.content || !c.content.parts) return "";
    var text = "";
    for (var i = 0; i < c.content.parts.length; i++) {
        var p = c.content.parts[i];
        if (p && p.text && !p.thought) text += String(p.text);
    }
    return text;
}

function geminiErrorMessage(response) {
    try {
        var d = response.json();
        if (d && d.error && d.error.message) return String(d.error.message);
    } catch (e) {}
    return "HTTP " + response.status;
}

function postGemini(url, body, key) {
    return fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify(body),
        timeout: 60000
    });
}

function romajiByGemini(inputs, keys) {
    var modelName = readModel();
    var style = readVowelStyle();
    var url = GEMINI_BASE + "/" + modelName + ":generateContent";
    var body = {
        systemInstruction: { parts: [{ text: buildPrompt(style) }] },
        contents: [{ role: "user", parts: [{ text: JSON.stringify(inputs) }] }],
        generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json",
            responseSchema: { type: "ARRAY", items: { type: "STRING" } }
        }
    };
    var withThinking = modelName.indexOf("gemini-2") !== 0;
    if (withThinking) body.generationConfig.thinkingConfig = { thinkingLevel: "low" };

    var lastMsg = "";
    for (var i = 0; i < keys.length; i++) {
        var response = postGemini(url, body, keys[i]);
        if (!response.ok && response.status === 400 && withThinking) {
            delete body.generationConfig.thinkingConfig;
            withThinking = false;
            response = postGemini(url, body, keys[i]);
        }
        if (response.ok) {
            var text = geminiText(response.json()).replace(/```json|```/g, "").trim();
            var arr;
            try {
                arr = JSON.parse(text);
            } catch (e) {
                return { error: "Gemini trả về không đúng định dạng: " + text.substring(0, 200) };
            }
            if (!Array.isArray(arr) || arr.length !== inputs.length) {
                return { error: "Gemini trả về sai số dòng (" + (arr && arr.length) + "/" + inputs.length + ")" };
            }
            var out = [];
            for (var j = 0; j < arr.length; j++) out.push(normalizeVowels(String(arr[j]).trim(), style));
            return { data: out };
        }
        lastMsg = geminiErrorMessage(response);
        if (response.status !== 429 && response.status !== 403) {
            return { error: "Gemini lỗi: " + lastMsg };
        }
    }
    return { error: "Tất cả API key đều lỗi hoặc hết quota: " + lastMsg };
}

function pickRomaji(data, index) {
    if (!data || !data[0]) return "";
    var parts = data[0];
    var s = "";
    for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        if (p && (p[0] === null || p[0] === undefined) && p.length > index && p[index]) {
            s += String(p[index]);
        }
    }
    return s.trim();
}

function romajiByGoogle(inputs, from) {
    var style = readVowelStyle();
    var isJa = from === "ja";
    var out = [];
    for (var i = 0; i < inputs.length; i++) {
        var url = GOOGLE_URL + "?client=gtx&sl=" + (isJa ? "ja" : "zh-CN") + "&tl=" + (isJa ? "en" : "ja")
            + "&dt=t&dt=rm&q=" + encodeURIComponent(inputs[i]);
        var response = fetch(url, { headers: { "User-Agent": UserAgent.chrome() }, timeout: 20000 });
        if (!response.ok) return { error: "Google Translate lỗi HTTP " + response.status };
        var romaji = pickRomaji(response.json(), isJa ? 3 : 2);
        if (!romaji) return { error: "Google Translate không trả về phiên âm cho: " + inputs[i] };
        out.push(normalizeVowels(titleCase(romaji), style));
    }
    return { data: out };
}
