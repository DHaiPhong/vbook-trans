load('config.js');
// Extension chỉ lo phần khám phá BXH; mục lục là 1 trang hướng dẫn đọc
function execute(url) {
    return Response.success([{ name: "Thông tin & cách đọc", url: officialLink(url) + "#bxh-info" }]);
}
