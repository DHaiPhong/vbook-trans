load('config.js');
function execute(url) {
    var meta = loadMeta(url) || metaFromUrl(url);
    if (!meta || !meta.t) return Response.error("Không có dữ liệu truyện — mở lại từ BXH");
    var links = [];
    var stv = stvLink(meta);
    if (stv) links.push("<a href=\"" + stv + "\">Mở trên Sáng Tác Việt</a>");
    links.push("<a href=\"" + officialLink(meta.link) + "\">Trang gốc " + (PLATFORM[meta.pid] || "") + "</a>");
    var suggests = (meta.ranks || []).filter(function (r) { return !!boardById(r.id); }).map(function (r) {
        return { title: "BXH: " + r.b, input: r.id, script: "rank.js" };
    });
    return Response.success({
        name: displayName(meta.t),
        author: meta.a || "",
        cover: meta.c || "",
        description: esc(meta.d).replace(/\n/g, "<br>"),
        detail: infoHtml(meta) + "<br>" + links.join(" · "),
        url: url,
        type: "novel",
        format: "novel",
        ongoing: true,
        suggests: suggests
    });
}
