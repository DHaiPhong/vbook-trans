var CFG = {
    name: "zh",
    channel: "m",
    ttl: 60,
    fq: "https://raw.githubusercontent.com/uu201/FanqieRankTracker/main",
    stv: "https://sangtacviet.vip"
};
try { CFG.name = String(NAME_MODE).split(" ")[0] || "zh"; } catch (e) { }
try { CFG.channel = String(CHANNEL).split(" ")[0] || "m"; } catch (e) { }
try { var _ttl = parseInt(CACHE_MINUTES, 10); if (_ttl >= 0) CFG.ttl = _ttl; } catch (e) { }
try { if (FANQIE_API) CFG.fq = String(FANQIE_API).replace(/\/+$/, ""); } catch (e) { }
try { if (STV_DOMAIN) CFG.stv = String(STV_DOMAIN).replace(/\/+$/, ""); } catch (e) { }

var UA_M = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
var UA_PC = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

// kind: agg | qd (m.qidian, dự phòng tophub qua th) | th (tophub.today) | fq | jj | bd
// per: kỳ để xếp tab ở trang chủ; home: hiện ở trang chủ; mem: thành phần + trọng số của tab Tổng hợp
var BOARDS = [
    { id: "agg_m", g: "m", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp chung", sub: "Qidian · Tung Hoành · Fanqie · Qimao · Baidu", mem: { qd_yuepiao: 1.2, qd_hotsales: 1.0, qd_readindex: 0.8, qd_rec_week: 0.5, zh_yuepiao: 0.8, zh_sale24: 0.6, fq_male_read: 1.0, qm_boy_hot: 0.8, bd_m: 0.3 } },
    { id: "agg_m_day", g: "m", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp ngày", sub: "Bán chạy/đọc nhiều trong ngày", mem: { qd_hotsales: 1.0, zh_sale24: 0.8, fq_male_read: 1.0, qm_boy_hot: 0.8, bd_m: 0.3 } },
    { id: "agg_m_week", g: "m", kind: "agg", home: 1, title: "🔥 Tổng hợp tuần", sub: "Đề cử & chỉ số đọc", mem: { qd_rec_week: 1.0, qd_readindex: 1.0, zh_rec: 0.8 } },
    { id: "agg_m_month", g: "m", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp tháng", sub: "Nguyệt phiếu & đề cử tháng", mem: { qd_yuepiao: 1.2, qd_rec_month: 0.8, zh_yuepiao: 1.0 } },
    { id: "agg_m_total", g: "m", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp mọi thời đại", sub: "Đề cử tổng · cất giữ · hoàn thành", mem: { qd_rec_total: 1.0, qd_collect: 1.0, zh_finish: 0.8, qm_boy_collect: 0.6, tsj_finish: 0.8 } },
    { id: "agg_m_new", g: "m", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp sách mới", sub: "Các bảng sách mới", mem: { qd_signnew: 1.0, qd_newauthor: 0.8, qd_newsign: 0.8, qd_pubnew: 0.6, zh_new: 0.8, qm_boy_new: 0.6, fq_male_new: 1.0, tsj_new: 0.4 } },

    { id: "qd_hotsales", g: "m", kind: "qd", base: "hotsales", th: "VaobmGneAj", q: "起点中文网", grp: "Qidian", name: "Bán chạy", per: "Ngày", home: 1, short: "QD Bán chạy" },
    { id: "qd_readindex", g: "m", kind: "qd", base: "readindex", th: "4MdALOlvxD", q: "起点中文网", grp: "Qidian", name: "Chỉ số đọc", per: "Tuần", home: 1, short: "QD Chỉ số đọc" },
    { id: "qd_rec_week", g: "m", kind: "qd", base: "rec", period: "3", th: "4qv9agmvaK", q: "起点中文网", grp: "Qidian", name: "Đề cử", per: "Tuần", home: 1, short: "QD Đề cử tuần" },
    { id: "qd_yuepiao", g: "m", kind: "qd", base: "yuepiao", th: "BwdG0p6ePx", q: "起点中文网", grp: "Qidian", name: "Nguyệt phiếu", per: "Tháng", home: 1, short: "QD Nguyệt phiếu" },
    { id: "qd_rec_month", g: "m", kind: "qd", base: "rec", period: "2", grp: "Qidian", name: "Đề cử", per: "Tháng", home: 1, short: "QD Đề cử tháng" },
    { id: "qd_yuepiao_prev", g: "m", kind: "qd", base: "yuepiao", prev: 1, grp: "Qidian", name: "Nguyệt phiếu tháng trước", per: "Tháng", short: "QD NP tháng trước" },
    { id: "qd_rec_total", g: "m", kind: "qd", base: "rec", period: "1", grp: "Qidian", name: "Đề cử", per: "Tổng", home: 1, short: "QD Đề cử tổng" },
    { id: "qd_collect", g: "m", kind: "th", node: "JndkabAo3V", q: "起点中文网", grp: "Qidian", name: "Cất giữ", per: "Tổng", home: 1, short: "QD Cất giữ" },
    { id: "qd_vipcollect", g: "m", kind: "th", node: "3adqzM3eng", q: "起点中文网", grp: "Qidian", name: "Cất giữ VIP", per: "Tổng", short: "QD Cất giữ VIP" },
    { id: "qd_signnew", g: "m", kind: "th", node: "MZd7B93vrO", q: "起点中文网", grp: "Qidian", name: "Sách mới tác giả ký hợp đồng", per: "Mới", home: 1, short: "QD Sách mới ký HĐ" },
    { id: "qd_newauthor", g: "m", kind: "th", node: "RrvWVk1o5z", q: "起点中文网", grp: "Qidian", name: "Sách mới tác giả mới", per: "Mới", short: "QD Tác giả mới" },
    { id: "qd_newsign", g: "m", kind: "th", node: "Ywv4BQNePa", q: "起点中文网", grp: "Qidian", name: "Sách mới vừa ký", per: "Mới", short: "QD Vừa ký" },
    { id: "qd_pubnew", g: "m", kind: "th", node: "YKd6RkzdaP", q: "起点中文网", grp: "Qidian", name: "Sách mới tác giả tự do", per: "Mới", short: "QD Tác giả tự do" },
    { id: "qd_fans", g: "m", kind: "th", node: "2me3NAndwj", q: "起点中文网", grp: "Qidian", name: "Thư hữu", per: "", short: "QD Thư hữu" },
    { id: "qd_free", g: "m", kind: "th", node: "5PdM16Rdmg", q: "起点中文网", grp: "Qidian", name: "Miễn phí có hạn", per: "", short: "QD Miễn phí" },

    { id: "zh_sale24", g: "m", kind: "th", node: "b0vmYyJvB1", q: "纵横中文网", grp: "Tung Hoành", name: "Bán chạy 24h", per: "Ngày", home: 1, short: "TH Bán chạy 24h" },
    { id: "zh_update24", g: "m", kind: "th", node: "BwdGrlgvPx", q: "纵横中文网", grp: "Tung Hoành", name: "Cập nhật 24h", per: "Ngày", short: "TH Cập nhật" },
    { id: "zh_rec", g: "m", kind: "th", node: "5PdMa5Gdmg", q: "纵横中文网", grp: "Tung Hoành", name: "Đề cử", per: "Tuần", short: "TH Đề cử" },
    { id: "zh_yuepiao", g: "m", kind: "th", node: "m4ejxR3vxE", q: "纵横中文网", grp: "Tung Hoành", name: "Nguyệt phiếu", per: "Tháng", home: 1, short: "TH Nguyệt phiếu" },
    { id: "zh_finish", g: "m", kind: "th", node: "47o8R5qdMm", q: "纵横中文网", grp: "Tung Hoành", name: "Hoàn thành", per: "Tổng", home: 1, short: "TH Hoàn thành" },
    { id: "zh_new", g: "m", kind: "th", node: "qndgqbpoLl", q: "纵横中文网", grp: "Tung Hoành", name: "Sách mới", per: "Mới", short: "TH Sách mới" },
    { id: "zh_newsub", g: "m", kind: "th", node: "DOvn3jVdEB", q: "纵横中文网", grp: "Tung Hoành", name: "Sách mới đặt mua", per: "Mới", short: "TH Sách mới đặt mua" },
    { id: "zh_click", g: "m", kind: "th", node: "aqeE5gxe9R", q: "纵横中文网", grp: "Tung Hoành", name: "Lượt xem", per: "", short: "TH Lượt xem" },
    { id: "zh_pengchang", g: "m", kind: "th", node: "Vaoby5geAj", q: "纵横中文网", grp: "Tung Hoành", name: "Ủng hộ (捧场)", per: "", short: "TH Ủng hộ" },

    { id: "fq_male_read", g: "m", kind: "fq", slug: "male-read", grp: "Fanqie", name: "Đọc nhiều", per: "Ngày", home: 1, short: "FQ Đọc nhiều" },
    { id: "fq_male_new", g: "m", kind: "fq", slug: "male-new", grp: "Fanqie", name: "Sách mới", per: "Mới", home: 1, short: "FQ Sách mới" },

    { id: "qm_boy_hot", g: "m", kind: "th", node: "anop3J0elZ", q: "七猫", grp: "Qimao", name: "Đại nhiệt", per: "Ngày", home: 1, short: "QM Đại nhiệt" },
    { id: "qm_boy_rise", g: "m", kind: "th", node: "8Rv2n31vLw", q: "七猫", grp: "Qimao", name: "Tăng nhanh (飞跃)", per: "", short: "QM Tăng nhanh" },
    { id: "qm_boy_fengyun", g: "m", kind: "th", node: "ARe13G8v7n", q: "七猫", grp: "Qimao", name: "Phong vân", per: "", short: "QM Phong vân" },
    { id: "qm_boy_collect", g: "m", kind: "th", node: "pQvNyNAoNE", q: "七猫", grp: "Qimao", name: "Cất giữ", per: "Tổng", short: "QM Cất giữ" },
    { id: "qm_boy_finish", g: "m", kind: "th", node: "ENeYWbGvY4", q: "七猫", grp: "Qimao", name: "Hoàn thành", per: "Tổng", short: "QM Hoàn thành" },
    { id: "qm_boy_new", g: "m", kind: "th", node: "4KvxyQEdkx", q: "七猫", grp: "Qimao", name: "Sách mới", per: "Mới", short: "QM Sách mới" },
    { id: "qm_boy_update", g: "m", kind: "th", node: "YKd6zJndaP", q: "七猫", grp: "Qimao", name: "Cập nhật", per: "", short: "QM Cập nhật" },

    { id: "tsj_sale", g: "m", kind: "th", node: "DOvnNO1vEB", q: "小说", grp: "Tuishujun", name: "Bán chạy (100)", per: "", short: "TSJ Bán chạy" },
    { id: "tsj_finish", g: "m", kind: "th", node: "47o8QGjvMm", q: "小说", grp: "Tuishujun", name: "Hoàn thành kinh điển (100)", per: "Tổng", home: 1, short: "TSJ Hoàn thành" },
    { id: "tsj_new", g: "m", kind: "th", node: "6YoVVaDoZa", q: "小说", grp: "Tuishujun", name: "Sách mới (100)", per: "Mới", short: "TSJ Sách mới" },
    { id: "bd_m", g: "m", kind: "bd", th: "anopNgqdlZ", q: "小说", grp: "Baidu", name: "Hot search", per: "", short: "Baidu" },

    { id: "agg_f", g: "f", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp chung · Nữ", sub: "Qidian Nữ · Fanqie · Qimao · Tấn Giang · Baidu", mem: { qdmm_yuepiao: 1.2, qdmm_hotsales: 1.0, fq_female_read: 1.0, qm_girl_hot: 0.8, jj_month: 1.0, bd_f: 0.3 } },
    { id: "agg_f_day", g: "f", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp ngày · Nữ", sub: "Bán chạy/đọc nhiều trong ngày", mem: { qdmm_hotsales: 1.0, fq_female_read: 1.0, qm_girl_hot: 0.8, bd_f: 0.3 } },
    { id: "agg_f_month", g: "f", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp tháng · Nữ", sub: "Nguyệt phiếu & bảng tháng", mem: { qdmm_yuepiao: 1.2, jj_month: 1.0 } },
    { id: "agg_f_total", g: "f", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp mọi thời đại · Nữ", sub: "Cất giữ · hoàn thành", mem: { qdmm_collect: 1.0, qm_girl_collect: 0.8, qm_girl_finish: 0.6 } },
    { id: "agg_f_new", g: "f", kind: "agg", ex: 1, home: 1, title: "🔥 Tổng hợp sách mới · Nữ", sub: "Các bảng sách mới", mem: { qdmm_newsale: 1.0, fq_female_new: 1.0, qm_girl_new: 0.8 } },

    { id: "qdmm_hotsales", g: "f", kind: "th", node: "DgeygBwvZq", q: "起点中文网", grp: "Qidian Nữ", name: "Bán chạy", per: "Ngày", home: 1, short: "QDN Bán chạy" },
    { id: "qdmm_readindex", g: "f", kind: "th", node: "2KeDGardNP", q: "起点中文网", grp: "Qidian Nữ", name: "Chỉ số đọc", per: "Tuần", short: "QDN Chỉ số đọc" },
    { id: "qdmm_rec", g: "f", kind: "th", node: "3adqZPLeng", q: "起点中文网", grp: "Qidian Nữ", name: "Đề cử", per: "Tuần", short: "QDN Đề cử" },
    { id: "qdmm_yuepiao", g: "f", kind: "th", node: "wkvlBRpez1", q: "起点中文网", grp: "Qidian Nữ", name: "Nguyệt phiếu", per: "Tháng", home: 1, short: "QDN Nguyệt phiếu" },
    { id: "qdmm_collect", g: "f", kind: "th", node: "2me39GEvwj", q: "起点中文网", grp: "Qidian Nữ", name: "Cất giữ", per: "Tổng", home: 1, short: "QDN Cất giữ" },
    { id: "qdmm_newsale", g: "f", kind: "th", node: "aEdZZPNdrO", q: "起点中文网", grp: "Qidian Nữ", name: "Sách mới bán chạy", per: "Mới", short: "QDN Sách mới" },
    { id: "fq_female_read", g: "f", kind: "fq", slug: "female-read", grp: "Fanqie Nữ", name: "Đọc nhiều", per: "Ngày", home: 1, short: "FQ Đọc nhiều" },
    { id: "fq_female_new", g: "f", kind: "fq", slug: "female-new", grp: "Fanqie Nữ", name: "Sách mới", per: "Mới", home: 1, short: "FQ Sách mới" },
    { id: "qm_girl_hot", g: "f", kind: "th", node: "JndkOEQd3V", q: "七猫", grp: "Qimao Nữ", name: "Đại nhiệt", per: "Ngày", home: 1, short: "QM Đại nhiệt" },
    { id: "qm_girl_rise", g: "f", kind: "th", node: "RrvW0Ogd5z", q: "七猫", grp: "Qimao Nữ", name: "Tăng nhanh (飞跃)", per: "", short: "QM Tăng nhanh" },
    { id: "qm_girl_fengyun", g: "f", kind: "th", node: "Ywv4PJzvPa", q: "七猫", grp: "Qimao Nữ", name: "Phong vân", per: "", short: "QM Phong vân" },
    { id: "qm_girl_collect", g: "f", kind: "th", node: "Vaob1bqeAj", q: "七猫", grp: "Qimao Nữ", name: "Cất giữ", per: "Tổng", short: "QM Cất giữ" },
    { id: "qm_girl_finish", g: "f", kind: "th", node: "4MdAkaboxD", q: "七猫", grp: "Qimao Nữ", name: "Hoàn thành", per: "Tổng", short: "QM Hoàn thành" },
    { id: "qm_girl_new", g: "f", kind: "th", node: "4qv95bnvaK", q: "七猫", grp: "Qimao Nữ", name: "Sách mới", per: "Mới", short: "QM Sách mới" },
    { id: "qm_girl_update", g: "f", kind: "th", node: "2me30xXowj", q: "七猫", grp: "Qimao Nữ", name: "Cập nhật", per: "", short: "QM Cập nhật" },
    { id: "jj_month", g: "f", kind: "jj", orderstr: "7", grp: "Tấn Giang", name: "Bảng tháng", per: "Tháng", home: 1, short: "JJ Bảng tháng" },
    { id: "bd_f", g: "f", kind: "bd", grp: "Baidu", name: "Hot search (Nữ)", per: "", short: "Baidu" }
];

var PER_ORDER = ["Ngày", "Tuần", "Tháng", "Tổng", "Mới", ""];
var PRIO = { qd: 0, zh: 1, fq: 2, jj: 3, qm: 4, tsj: 5, bd: 6, x: 7 };
var PLATFORM = { qd: "Qidian", zh: "Tung Hoành", fq: "Fanqie", jj: "Tấn Giang", qm: "Qimao", tsj: "Tuishujun", bd: "Baidu", x: "Khác" };

function channels() {
    return CFG.channel === "all" ? ["m", "f"] : [CFG.channel === "f" ? "f" : "m"];
}

function boardById(id) {
    for (var i = 0; i < BOARDS.length; i++) if (BOARDS[i].id === id) return BOARDS[i];
    return null;
}

// Trang chủ: xếp theo kỳ — "Tháng · Qidian nguyệt phiếu"
function homeTitle(b) {
    if (b.kind === "agg") return b.title;
    var n = b.grp + " " + b.name.charAt(0).toLowerCase() + b.name.substring(1);
    return b.per ? b.per + " · " + n : n;
}

// Phân loại: xếp theo nguồn — "Qidian · Nguyệt phiếu [Tháng]"
function genreTitle(b) {
    return b.grp + " · " + b.name + (b.per ? " [" + b.per + "]" : "");
}

function boardTitle(b) {
    return b.kind === "agg" ? b.title : homeTitle(b);
}

// ---------- HTTP ----------
function httpText(url, opt) {
    opt = opt || {};
    var headers = { "User-Agent": opt.pc ? UA_PC : UA_M, "Accept-Language": "zh-CN,zh;q=0.9" };
    try {
        var res = fetch(url, { headers: headers, timeout: 20000 });
        if (!res.ok) return "";
        return String(opt.charset ? res.text(opt.charset) : res.text());
    } catch (e) {
        return "";
    }
}

function browserHtml(url) {
    var b = null;
    try {
        b = Engine.newBrowser();
        var doc = b.launch(url, 15000);
        var html = doc ? String(doc.html()) : "";
        b.close();
        return html;
    } catch (e) {
        try { if (b) b.close(); } catch (e2) { }
        return "";
    }
}

// ---------- Cache ----------
function cacheGet(key, allowStale) {
    try {
        var s = cacheStorage.getItem(key);
        if (!s) return null;
        var o = JSON.parse(String(s));
        if (!allowStale && (Date.now() - o.ts) > CFG.ttl * 60000) return null;
        return o.v;
    } catch (e) {
        return null;
    }
}

function cacheSet(key, v) {
    try { cacheStorage.setItem(key, JSON.stringify({ ts: Date.now(), v: v })); } catch (e) { }
}

// ---------- Helpers ----------
function findArray(obj, test, depth) {
    depth = depth || 0;
    if (!obj || depth > 8 || typeof obj !== "object") return null;
    if (Array.isArray(obj)) {
        if (obj.length && test(obj[0])) return obj;
        for (var i = 0; i < obj.length; i++) {
            var r = findArray(obj[i], test, depth + 1);
            if (r) return r;
        }
        return null;
    }
    for (var k in obj) {
        if (!obj.hasOwnProperty(k)) continue;
        var r2 = findArray(obj[k], test, depth + 1);
        if (r2) return r2;
    }
    return null;
}

function parseWan(s) {
    var m = String(s || "").replace(/,/g, "").match(/([\d.]+)\s*(万|亿)?/);
    if (!m) return 0;
    var n = parseFloat(m[1]);
    if (m[2] === "万") n *= 1e4;
    if (m[2] === "亿") n *= 1e8;
    return n;
}

function clean(s) {
    return String(s || "").replace(/\s+/g, " ").trim();
}

function normTitle(t) {
    return String(t || "").replace(/[\s\u3000·•，,。.！!？?：:、（）()《》【】\[\]“”"'‘’—\-~～]/g, "").toLowerCase();
}

function prevMonth() {
    var d = new Date();
    var y = d.getFullYear(), m = d.getMonth();
    if (m === 0) { y = y - 1; m = 12; }
    return String(y) + (m < 10 ? "0" : "") + m;
}

// ---------- Qidian (m.qidian.com, SSR) ----------
function qdPath(b, cat) {
    // Đề cử: /rank/rec/catid{cat}/{3=tuần,2=tháng,1=tổng}/
    if (b.base === "rec") return "/rank/rec/catid" + (cat || "-1") + "/" + b.period + "/";
    var c = cat ? "catid" + cat + "/" : "";
    if (b.prev) return "/rank/yuepiao/" + c + prevMonth() + "/";
    return "/rank/" + b.base + "/" + c;
}

function qidianRecords(html) {
    if (!html) return [];
    // Danh sách nằm trong JSON SSR của vite-plugin-ssr, không phải DOM
    var m = html.match(/<script[^>]+id=["']vite-plugin-ssr_pageContext["'][^>]*>([\s\S]*?)<\/script>/i);
    if (!m) return [];
    var obj;
    try { obj = JSON.parse(m[1]); } catch (e) { return []; }
    var pd = obj && obj.pageContext && obj.pageContext.pageProps && obj.pageContext.pageProps.pageData;
    var recs = pd && pd.records;
    if (!recs || !recs.length) {
        recs = findArray(obj, function (o) { return o && (o.bid || o.bookId) && (o.bName || o.bookName); });
    }
    return recs || [];
}

function fetchQidian(path, allowBrowser) {
    var url = "https://m.qidian.com" + path;
    var recs = qidianRecords(httpText(url));
    if (!recs.length && allowBrowser) recs = qidianRecords(browserHtml(url));
    var out = [];
    recs.forEach(function (r) {
        var bid = String(r.bid || r.bookId || "");
        var t = clean(r.bName || r.bookName);
        if (!bid || !t) return;
        out.push({
            t: t,
            a: clean(r.bAuth || r.authorName || r.author),
            c: "https://bookcover.yuewen.com/qdbimg/349573/" + bid + "/180",
            d: clean(r.desc),
            cat: [r.cat, r.subCat].filter(function (x) { return !!x; }).join("·"),
            words: r.cnt ? String(r.cnt) : "",
            v: r.rankCnt ? String(r.rankCnt) : "",
            pid: "qd", rid: bid,
            link: "https://m.qidian.com/book/" + bid + "/#bxh"
        });
    });
    return out;
}

// ---------- Fanqie (JSON đã giải mã từ FanqieRankTracker) ----------
function fetchFanqie(slug, cat) {
    var url = CFG.fq + "/api/" + slug + "/lastest/all.json";
    var txt = cacheGet("R:" + url);
    if (!txt) {
        txt = httpText(url, { pc: true });
        if (txt) cacheSet("R:" + url, txt); else txt = cacheGet("R:" + url, true);
    }
    if (!txt) return [];
    var data;
    try { data = JSON.parse(txt); } catch (e) { return []; }
    var out = [], seen = {};
    (data.categories || []).forEach(function (c) {
        if (cat && c.name !== cat) return;
        (c.books || []).forEach(function (b) {
            var m = String(b.url || "").match(/\/page\/(\d+)/);
            if (!m || seen[m[1]]) return;
            seen[m[1]] = 1;
            out.push({
                t: clean(b.title), a: clean(b.author), c: b.cover || "", d: clean(b.intro),
                cat: c.name || "", words: "",
                v: b.reads ? b.reads + " đang đọc" : "", n: parseWan(b.reads),
                pid: "fq", rid: m[1],
                link: "https://fanqienovel.com/page/" + m[1] + "#bxh"
            });
        });
    });
    if (!cat) out.sort(function (x, y) { return y.n - x.n; });
    return out;
}

// ---------- Tấn Giang (GB18030) ----------
function fetchJJ(orderstr) {
    var html = httpText("https://www.jjwxc.net/topten.php?orderstr=" + orderstr + "&t=0", { pc: true, charset: "gb18030" });
    if (!html) return [];
    var doc = Html.parse(html);
    var out = [], seen = {};
    doc.select("tr:not(:has(tr))").forEach(function (tr) {
        var ta = tr.select("a[href*='onebook.php?novelid=']");
        if (ta.isEmpty()) return;
        var a0 = ta.first();
        var m = String(a0.attr("href")).match(/novelid=(\d+)/);
        if (!m || seen[m[1]]) return;
        seen[m[1]] = 1;
        var au = tr.select("a[href*='oneauthor.php']");
        out.push({
            t: clean(a0.text()), a: au.isEmpty() ? "" : clean(au.first().text()),
            c: "", d: clean(a0.attr("title")), cat: "", words: "", v: "",
            pid: "jj", rid: m[1],
            link: "https://www.jjwxc.net/onebook.php?novelid=" + m[1] + "#bxh"
        });
    });
    return out.filter(function (x) { return !!x.t; });
}

// ---------- Baidu (s-data JSON trong comment HTML) ----------
function fetchBaiduAll() {
    var key = "B:bd_all";
    var cached = cacheGet(key);
    if (cached) return cached;
    var html = httpText("https://top.baidu.com/board?tab=novel", { pc: true });
    var out = [];
    // Baidu nhúng dữ liệu BXH dạng JSON trong <!--s-data:...-->
    var m = html.match(/<!--s-data:([\s\S]*?)-->/);
    if (m) {
        try {
            var arr = findArray(JSON.parse(m[1]), function (o) { return o && o.word; }) || [];
            arr.forEach(function (o) {
                var raw = JSON.stringify(o);
                var au = raw.match(/作者[：:]\s*([^"，,\\]+)/);
                var ct = raw.match(/类型[：:]\s*([^"，,\\|]+)/);
                var t = clean(o.word);
                out.push({
                    t: t, a: au ? clean(au[1]) : clean(o.author), c: o.img || "", d: clean(o.desc),
                    cat: ct ? clean(ct[1]) : clean(o.category), words: "",
                    v: o.hotScore ? o.hotScore + " điểm hot" : "",
                    pid: "bd", rid: t,
                    link: "https://www.baidu.com/s?wd=" + encodeURIComponent(t + " 小说") + "#bxh"
                });
            });
        } catch (e) { }
    }
    if (!out.length && html) {
        var seen = {};
        Html.parse(html).select("a[href*='fyb_novel']").forEach(function (a) {
            var mm = String(a.attr("href")).match(/[?&]wd=([^&]+)/);
            if (!mm) return;
            var t = clean(decodeURIComponent(mm[1].replace(/\+/g, " ")).replace(/\s*小说$/, ""));
            if (!t || seen[t]) return;
            seen[t] = 1;
            out.push({ t: t, a: "", c: "", d: "", cat: "", words: "", v: "", pid: "bd", rid: t, link: "https://www.baidu.com/s?wd=" + encodeURIComponent(t + " 小说") + "#bxh" });
        });
    }
    if (out.length) cacheSet(key, out); else out = cacheGet(key, true) || [];
    return out;
}

// ---------- Link → nền tảng ----------
function linkInfo(href) {
    href = String(href || "");
    var m;
    if ((m = href.match(/(?:qidian|qdmm)\.com\/(?:book|info)\/(\d+)/))) {
        return { pid: "qd", rid: m[1], link: "https://m.qidian.com/book/" + m[1] + "/#bxh", cover: "https://bookcover.yuewen.com/qdbimg/349573/" + m[1] + "/180" };
    }
    if ((m = href.match(/zongheng\.com\/(?:detail|book)\/(\d+)/))) return { pid: "zh", rid: m[1], link: "https://www.zongheng.com/detail/" + m[1] + "#bxh", cover: "" };
    if ((m = href.match(/fanqienovel\.com\/page\/(\d+)/))) return { pid: "fq", rid: m[1], link: "https://fanqienovel.com/page/" + m[1] + "#bxh", cover: "" };
    if ((m = href.match(/qimao\.com\/shuku\/(\d+)/))) return { pid: "qm", rid: m[1], link: "https://www.qimao.com/shuku/" + m[1] + "/#bxh", cover: "" };
    if ((m = href.match(/tuishujun\.com\/books\/(\d+)/))) return { pid: "tsj", rid: m[1], link: "https://www.tuishujun.com/books/" + m[1] + "#bxh", cover: "" };
    if ((m = href.match(/novelid=(\d+)/))) return { pid: "jj", rid: m[1], link: "https://www.jjwxc.net/onebook.php?novelid=" + m[1] + "#bxh", cover: "" };
    if ((m = href.match(/baidu\.com\/s\?.*?wd=([^&#]+)/))) {
        var t = "";
        try { t = decodeURIComponent(m[1].replace(/\+/g, " ")).replace(/\s*小说$/, ""); } catch (e) { t = m[1]; }
        return { pid: "bd", rid: t, link: "https://www.baidu.com/s?wd=" + encodeURIComponent(t + " 小说") + "#bxh", cover: "" };
    }
    return { pid: "x", rid: href, link: href.replace(/#.*$/, "") + "#bxh", cover: "" };
}

function isNumberish(s) {
    return /^[\d.,\s]+(万|亿|w|W|k|K)?$/.test(String(s || ""));
}

function makeItem(title, href, author, desc, cover, v) {
    var info = linkInfo(href);
    return {
        t: clean(title), a: clean(author), c: cover || info.cover || "", d: clean(desc),
        cat: "", words: "", v: v || "", pid: info.pid, rid: info.rid, link: info.link
    };
}

// ---------- tophub.today ----------
// Trang danh mục: mỗi thẻ div.cc-cd là 1 BXH (20–100 truyện), item = a[itemid] > span.s/.t/.e
function thParseCards(html) {
    var map = {};
    if (!html) return map;
    Html.parse(html).select("div.cc-cd").forEach(function (card) {
        var head = card.select("a[href*='/n/']");
        if (head.isEmpty()) return;
        var m = String(head.first().attr("href")).match(/\/n\/([A-Za-z0-9]+)/);
        if (!m) return;
        var items = [], seen = {};
        card.select("a[itemid]").forEach(function (a) {
            var t = a.select("span.t");
            var title = t.isEmpty() ? clean(a.text()) : clean(t.first().text());
            if (!title) return;
            var e = a.select("span.e");
            var extra = e.isEmpty() ? "" : clean(e.first().text());
            var num = isNumberish(extra);
            var it = makeItem(title, String(a.attr("href")), num ? "" : extra, "", "", num && extra.length > 2 ? extra : "");
            if (seen[it.link]) return;
            seen[it.link] = 1;
            items.push(it);
        });
        if (items.length) map[m[1]] = items;
    });
    return map;
}

var TH_MEMO = {};
function thBatch(q, p) {
    var key = "TB:" + q + "|" + p;
    if (TH_MEMO[key]) return TH_MEMO[key];
    var cached = cacheGet(key);
    if (cached) return cached;
    var html = httpText("https://tophub.today/c/ent?q=" + encodeURIComponent(q) + "&p=" + p, { pc: true });
    if (!html) {
        TH_MEMO[key] = cacheGet(key, true) || { __fail: 1 };
        return TH_MEMO[key];
    }
    var map = thParseCards(html);
    cacheSet(key, map);
    return map;
}

// Trang riêng của 1 BXH: có ảnh bìa + giới thiệu + tác giả
function unescapeHtml(s) {
    return String(s || "").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&amp;/g, "&");
}

function thParseNode(html) {
    var out = [];
    if (!html) return out;
    var seen = {};
    Html.parse(html).select("table tr").forEach(function (tr) {
        var links = tr.select("a[href]"), a = null;
        for (var i = 0; i < links.size(); i++) {
            var l = links.get(i), h = String(l.attr("href"));
            if (/^(javascript|#|\/)/.test(h) || /tophub\.today/.test(h) || !clean(l.text())) continue;
            a = l;
            break;
        }
        if (!a) return;
        var title = clean(a.text());
        var cover = "";
        var img = tr.select("img");
        if (!img.isEmpty()) {
            var im = img.first();
            cover = String(im.attr("data-src") || im.attr("data-original") || im.attr("src") || "");
            if (cover.indexOf("//") === 0) cover = "https:" + cover;
        }
        // Ô chứa tên: tách phần còn lại theo từng thẻ/đoạn chữ → [giới thiệu..., tác giả]
        var segs = [];
        tr.select("td").forEach(function (td) {
            if (segs.length || clean(td.text()).indexOf(title) !== 0) return;
            var inner = String(td.html()).replace(/<a\b[^>]*>[\s\S]*?<\/a>/i, "");
            inner.split(/<[^>]+>/).forEach(function (piece) {
                var t = clean(unescapeHtml(piece));
                if (t) segs.push(t);
            });
            if (!segs.length) segs.push("");
        });
        segs = segs.filter(function (x) { return !!x; });
        var author = "", desc = "";
        if (segs.length >= 2) {
            author = segs[segs.length - 1];
            desc = segs.slice(0, -1).join(" ");
        } else if (segs.length === 1) {
            var mm = segs[0].match(/^([\s\S]*\S)\s+(\S{1,20})$/);
            if (mm) { desc = mm[1]; author = mm[2]; }
            else if (segs[0].length <= 20) author = segs[0];
            else desc = segs[0];
        }
        if (author.length > 20) { desc = (desc + " " + author).trim(); author = ""; }
        var v = "";
        if (isNumberish(author)) { v = author.length > 2 ? author : ""; author = ""; }
        var it = makeItem(title, String(a.attr("href")), author, desc, cover, v);
        if (seen[it.link]) return;
        seen[it.link] = 1;
        out.push(it);
    });
    return out;
}

function fetchTophub(node, q, rich) {
    if (rich) {
        var list = thParseNode(httpText("https://tophub.today/n/" + node, { pc: true }));
        if (list.length >= 3) return list;
    }
    if (q) {
        for (var p = 1; p <= 3; p++) {
            var map = thBatch(q, p);
            if (map[node]) return map[node];
            if (map.__fail) break;
        }
    }
    if (!rich) return thParseNode(httpText("https://tophub.today/n/" + node, { pc: true }));
    return [];
}

// ---------- Board / Aggregate ----------
function getBoard(id, param, rich) {
    var b = boardById(id);
    if (!b || b.kind === "agg") return [];
    param = param || "";
    var keyRich = "B:" + id + "|" + param + "|r";
    var key = "B:" + id + "|" + param;
    var cached = cacheGet(keyRich) || (rich ? null : cacheGet(key));
    if (cached) return cached;
    var list = [];
    if (b.kind === "qd") {
        // Tab riêng: ưu tiên m.qidian (có số liệu); Tổng hợp: ưu tiên tophub (1 request ra nhiều bảng)
        if (!rich && b.th && !param) list = fetchTophub(b.th, b.q, false);
        if (!list.length) list = fetchQidian(qdPath(b, param), rich);
        if (!list.length && b.th && !param) list = fetchTophub(b.th, b.q, rich);
    }
    else if (b.kind === "th") list = fetchTophub(b.node, b.q, rich);
    else if (b.kind === "fq") list = fetchFanqie(b.slug, param);
    else if (b.kind === "jj") list = fetchJJ(b.orderstr);
    else if (b.kind === "bd") {
        list = fetchBaiduAll().filter(function (x) {
            var fem = /言情|青春/.test(x.cat);
            return b.g === "f" ? fem : !fem;
        });
        if (!list.length && b.th) list = fetchTophub(b.th, b.q, rich);
    }
    var k = (rich || b.kind === "fq" || b.kind === "jj" || b.kind === "bd") ? keyRich : key;
    if (list.length) cacheSet(k, list);
    else list = cacheGet(keyRich, true) || cacheGet(key, true) || [];
    return list;
}

function getAggregate(aggId) {
    var ab = boardById(aggId);
    if (!ab || ab.kind !== "agg") return [];
    var key = "A:" + aggId;
    var cached = cacheGet(key);
    if (cached) return cached;
    var map = {}, order = [];
    for (var mid in ab.mem) {
        if (!ab.mem.hasOwnProperty(mid)) continue;
        var b = boardById(mid);
        if (!b) continue;
        var w = ab.mem[mid];
        var list = getBoard(b.id, "", false);
        var N = Math.min(list.length, 50);
        for (var i = 0; i < N; i++) {
            var it = list[i], k = normTitle(it.t);
            if (!k) continue;
            var e = map[k];
            if (!e) {
                e = map[k] = { it: Object.assign({}, it), score: 0, ranks: [] };
                order.push(k);
            } else {
                var cur = e.it;
                if (PRIO[it.pid] < PRIO[cur.pid]) {
                    e.it = Object.assign({}, it);
                    ["a", "c", "d", "cat", "words"].forEach(function (f) { if (!e.it[f]) e.it[f] = cur[f]; });
                } else {
                    ["a", "c", "d", "cat", "words"].forEach(function (f) { if (!cur[f]) cur[f] = it[f]; });
                }
            }
            e.score += w * (N - i) / N;
            e.ranks.push({ id: b.id, b: b.short, r: i + 1, v: it.v || "" });
        }
    }
    var out = order.map(function (k) {
        var e = map[k];
        var it = e.it;
        it.ranks = e.ranks.sort(function (x, y) { return x.r - y.r; });
        it.score = Math.round(e.score * 100) / 100;
        return it;
    });
    out.sort(function (x, y) { return y.score - x.score; });
    if (out.length) cacheSet(key, out);
    return out;
}

// ---------- Tên / hiển thị ----------
function qtText(text, mode) {
    if (!text) return "";
    try {
        var r = Qt.translate(String(text), mode, mode === "vp" ? { chapter_name: true, first_capitalize: true } : { first_capitalize: true });
        return r && r.translateText ? clean(r.translateText) : "";
    } catch (e) {
        return "";
    }
}

function hvName(t) {
    var s = qtText(t, "hv");
    return s ? s.replace(/(^|\s)(\S)/g, function (m0, p, c) { return p + c.toUpperCase(); }) : "";
}

function displayName(t) {
    if (CFG.name === "hv") return hvName(t) || t;
    if (CFG.name === "vp") return qtText(t, "vp") || t;
    return t;
}

function altName(t) {
    return CFG.name === "zh" ? hvName(t) : t;
}

function ranksText(ranks, max) {
    return (ranks || []).slice(0, max || 3).map(function (r) { return r.b + " #" + r.r; }).join(", ");
}

function toListItem(it, rank) {
    var parts = [];
    var alt = altName(it.t);
    if (alt) parts.push(alt);
    if (it.a) parts.push(it.a);
    if (it.ranks) parts.push(ranksText(it.ranks, 3));
    else if (it.v) parts.push(it.v);
    if (it.cat) parts.push(it.cat);
    return {
        name: displayName(it.t),
        link: it.link,
        cover: it.c || "",
        description: parts.join(" · "),
        tag: it.ranks ? it.ranks.length + " BXH" : "#" + rank
    };
}

// ---------- Meta (localStorage) để detail/chap không phải tải lại ----------
function loadMeta(link) {
    try {
        var s = localStorage.getItem("M:" + link);
        return s ? JSON.parse(String(s)) : null;
    } catch (e) {
        return null;
    }
}

function saveMeta(it, newRanks) {
    var old = loadMeta(it.link);
    var ranks = (old && old.ranks) ? old.ranks : [];
    (newRanks || []).forEach(function (nr) {
        var hit = false;
        for (var i = 0; i < ranks.length; i++) {
            if (ranks[i].id === nr.id) { ranks[i] = nr; hit = true; break; }
        }
        if (!hit) ranks.push(nr);
    });
    var m = {
        t: it.t, a: it.a || (old && old.a) || "", c: it.c || (old && old.c) || "",
        d: String(it.d || (old && old.d) || "").substring(0, 800),
        cat: it.cat || (old && old.cat) || "", words: it.words || (old && old.words) || "",
        pid: it.pid, rid: it.rid, link: it.link, ranks: ranks
    };
    try { localStorage.setItem("M:" + it.link, JSON.stringify(m)); } catch (e) { }
    return m;
}

function renderItems(list, start, count, board) {
    var out = [];
    for (var i = start; i < Math.min(list.length, start + count); i++) {
        var it = list[i];
        if (it.ranks) saveMeta(it, it.ranks);
        else if (board) saveMeta(it, [{ id: board.id, b: board.short, r: i + 1, v: it.v || "" }]);
        out.push(toListItem(it, i + 1));
    }
    return out;
}

function officialLink(link) {
    return String(link || "").replace(/#bxh.*$/, "");
}

function stvLink(m) {
    var host = { qd: "qidian", fq: "fanqie", jj: "jjwxc", zh: "zongheng" }[m.pid];
    if (!host || !m.rid) return "";
    return CFG.stv + "/truyen/" + host + "/1/" + m.rid + "/";
}

function esc(s) {
    return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function metaFromUrl(url) {
    var off = officialLink(url);
    var info = linkInfo(off);
    if (info.pid === "x") return null;
    if (info.pid === "bd") return { t: info.rid, a: "", c: "", d: "", cat: "", words: "", pid: "bd", rid: info.rid, link: url, ranks: [] };
    var html = httpText(off, { pc: info.pid !== "qd", charset: info.pid === "jj" ? "gb18030" : "" });
    if (!html) return null;
    var doc = Html.parse(html);
    function metaProp(p) {
        var e = doc.select("meta[property='" + p + "']");
        return e.isEmpty() ? "" : clean(e.first().attr("content"));
    }
    var t = metaProp("og:novel:book_name") || metaProp("og:title") || clean(doc.select("title").text()).split(/[_\-|(（]/)[0];
    return {
        t: t, a: metaProp("og:novel:author"), c: metaProp("og:image") || info.cover,
        d: metaProp("og:description"), cat: metaProp("og:novel:category"), words: "",
        pid: info.pid, rid: info.rid, link: url, ranks: []
    };
}

function infoHtml(meta) {
    var lines = [];
    var hv = hvName(meta.t);
    lines.push("Tên gốc: " + esc(meta.t));
    if (hv) lines.push("Hán Việt: " + esc(hv));
    if (meta.a) lines.push("Tác giả: " + esc(meta.a));
    var sub = [];
    if (meta.cat) sub.push("Thể loại: " + esc(meta.cat));
    if (meta.words) sub.push("Số chữ: " + esc(meta.words));
    if (sub.length) lines.push(sub.join(" · "));
    lines.push("Nền tảng: " + (PLATFORM[meta.pid] || ""));
    if (meta.ranks && meta.ranks.length) {
        lines.push("Xếp hạng: " + meta.ranks.map(function (r) {
            return esc(r.b) + " #" + r.r + (r.v ? " (" + esc(r.v) + ")" : "");
        }).join(" · "));
    }
    return lines.join("<br>");
}
