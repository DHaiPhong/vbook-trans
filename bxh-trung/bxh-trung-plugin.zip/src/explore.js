load('config.js');
function execute() {
    var sections = [];
    channels().forEach(function (g) {
        var aggBoard = boardById("agg_" + g);
        var agg = getAggregate(g, false);
        if (agg.length) sections.push(makeSection(aggBoard, renderItems(agg, 0, 10, null), "Điểm cộng dồn từ nhiều BXH"));
        BOARDS.forEach(function (b) {
            if (b.g !== g || !b.ex) return;
            var list = getBoard(b.id, "", false);
            if (list.length) sections.push(makeSection(b, renderItems(list, 0, 10, b), ""));
        });
    });
    if (!sections.length) return Response.error("Không tải được BXH nào — kiểm tra mạng rồi thử lại");
    return Response.success(sections);
}

function makeSection(b, items, subtitle) {
    var more = { type: "list", name: b.title, script: "rank.js", input: b.id, data: "" };
    return { id: b.id, title: b.title, subtitle: subtitle, type: "ranking", items: items, more: more, action: more };
}
